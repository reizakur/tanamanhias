<?php
$con = mysqli_connect("localhost","joeloecs_user","4215kurnia","joeloecs_tanaman");

if (mysqli_connect_error ())
{
	echo "Failed broooo" .mysqli_connect_error();
}
?>
